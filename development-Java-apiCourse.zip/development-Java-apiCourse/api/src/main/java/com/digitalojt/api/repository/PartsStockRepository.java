package com.digitalojt.api.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.digitalojt.api.dto.PartsStockDto;
import com.digitalojt.api.entity.PartsStock;

public interface PartsStockRepository extends JpaRepository<PartsStock, Long> {

    @Query("""
        SELECT new com.digitalojt.api.dto.PartsStockDto(
            ps.id, ps.stockCode, ps.stockName, ps.currentStock,
            ps.safetyStock, ps.maxStock, ps.unit, ps.unitCost,
            ps.shelfLocation, ps.isActive, c.centerName, cat.categoryName
        )
        FROM PartsStock ps
        JOIN ps.center c
        JOIN ps.category cat
    """)
    List<PartsStockDto> findAllWithCategoryAndCenter();

    @Query("""
        SELECT new com.digitalojt.api.dto.PartsStockDto(
            ps.id, ps.stockCode, ps.stockName, ps.currentStock,
            ps.safetyStock, ps.maxStock, ps.unit, ps.unitCost,
            ps.shelfLocation, ps.isActive, c.centerName, cat.categoryName
        )
        FROM PartsStock ps
        JOIN ps.center c
        JOIN ps.category cat
    """)
    List<PartsStockDto> findAllWithRelations(); // ※findAllWithCategoryAndCenter と内容が同一であれば、片方削除可

    @Query("""
        SELECT new com.digitalojt.api.dto.PartsStockDto(
            ps.id, ps.stockCode, ps.stockName, ps.currentStock,
            ps.safetyStock, ps.maxStock, ps.unit, ps.unitCost,
            ps.shelfLocation, ps.isActive, c.centerName, cat.categoryName
        )
        FROM PartsStock ps
        JOIN ps.center c
        JOIN ps.category cat
        WHERE cat.id = :categoryId
    """)
    List<PartsStockDto> findByCategoryId(@Param("categoryId") Long categoryId);
    
    @Query("""
    	    SELECT new com.digitalojt.api.dto.PartsStockDto(
    	        ps.id, ps.stockCode, ps.stockName, ps.currentStock,
    	        ps.safetyStock, ps.maxStock, ps.unit, ps.unitCost,
    	        ps.shelfLocation, ps.isActive, c.centerName, cat.categoryName
    	    )
    	    FROM PartsStock ps
    	    JOIN ps.center c
    	    JOIN ps.category cat
    	    WHERE (:categoryId IS NULL OR cat.id = :categoryId)
    	      AND (:name IS NULL OR ps.stockName LIKE CONCAT('%', :name, '%'))
    	      AND (:amountMin IS NULL OR ps.currentStock >= :amountMin)
    	      AND (:amountMax IS NULL OR ps.currentStock <= :amountMax)
    	""")
    	List<PartsStockDto> searchPartsStockInfo(
    	    @Param("categoryId") Long categoryId,
    	    @Param("name") String name,
    	    @Param("amountMin") Integer amountMin,
    	    @Param("amountMax") Integer amountMax
    	);

}
