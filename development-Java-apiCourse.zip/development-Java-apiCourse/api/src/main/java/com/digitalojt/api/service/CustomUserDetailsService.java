package com.digitalojt.api.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.digitalojt.api.entity.AdminInfo;
import com.digitalojt.api.repository.AdminInfoRepository;

/**
 * カスタムユーザー詳細サービス
 * 
 * @author your name
 *
 */

@Service
public class CustomUserDetailsService implements UserDetailsService {
	
    @Autowired
    private AdminInfoRepository adminInfoRepository;
    
    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        AdminInfo adminInfo = adminInfoRepository.findByUsername(username)
            .orElseThrow(() -> new UsernameNotFoundException("User not found with username: " + username));
        
        List<SimpleGrantedAuthority> authorities = List.of(new SimpleGrantedAuthority("ROLE_USER"));

        return new org.springframework.security.core.userdetails.User(
            adminInfo.getUsername(),
            adminInfo.getPasswordHash(),
            authorities
        );
    }
}