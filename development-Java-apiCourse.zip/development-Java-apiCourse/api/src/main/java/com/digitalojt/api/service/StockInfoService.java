package com.digitalojt.api.service;

public class StockInfoService {

}
