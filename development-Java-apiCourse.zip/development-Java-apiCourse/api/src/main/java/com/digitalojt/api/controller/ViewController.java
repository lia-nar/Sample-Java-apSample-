package com.digitalojt.api.controller;

import java.util.Map;

import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
/**
 * login時に、静的HTML(login.html)にリダイレクトするControllerクラス
 * 
 * @author dotlife
 *
 */

@Controller
public class ViewController {

    @GetMapping("/login")
    public String loginPage() {
        return "forward:/html/login/login.html";
    }
    
    @GetMapping("/protected")
    public ResponseEntity<?> getProtectedData(Authentication auth) {
        return ResponseEntity.ok(Map.of(
            "message", "アクセス成功",
            "user", auth.getName(),
            "roles", auth.getAuthorities()
        ));
    }
}