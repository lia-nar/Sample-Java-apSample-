package com.digitalojt.api.form;

import lombok.Data;

/**
 * ログイン画面のフォームクラス
 * 
 * @author dotlife
 *
 */
@Data
public class LoginForm {

	/**
	 * 管理者ID
	 */
	private String username;

	/**
	 * パスワード
	 */
	private String password;
}
