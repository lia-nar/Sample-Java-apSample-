package com.digitalojt.api.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.digitalojt.api.dto.PartsStockDto;
import com.digitalojt.api.repository.PartsStockRepository;

@Service
public class PartsStockService {

    @Autowired
    private PartsStockRepository partsStockRepository;

    public List<PartsStockDto> findAll() {
        return partsStockRepository.findAllWithRelations();
    }

    public List<PartsStockDto> findByCategoryId(Long categoryId) {
        return partsStockRepository.findByCategoryId(categoryId);
    }

    public List<PartsStockDto> searchPartsStockInfo(Long categoryId, String name, Integer amountMin, Integer amountMax) {
        return partsStockRepository.searchPartsStockInfo(categoryId, name, amountMin, amountMax);
    }
}
