package com.digitalojt.api.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.digitalojt.api.dto.PartsStockDto;
import com.digitalojt.api.service.PartsStockService;

@Controller
@RequestMapping("/parts")
public class PartsStockController {

    private final PartsStockService partsStockService;

    public PartsStockController(PartsStockService partsStockService) {
        this.partsStockService = partsStockService;
    }

    @GetMapping
    public String list(Model model) {
        List<PartsStockDto> parts = partsStockService.findAll();
        model.addAttribute("partsList", parts);
        return "parts/list";
    }
    
    @GetMapping("/init")
    public List<PartsStockDto> getAllStock() {
        return partsStockService.findAll();
    }

    @GetMapping("/category")
    public List<PartsStockDto> findByCategoryId(@RequestParam(value = "categoryId", required = false) Long categoryId) {
        if (categoryId == null) {
            return partsStockService.findAll();
        }
        return partsStockService.findByCategoryId(categoryId);
    }
    
    // 検索機能
    @GetMapping("/search")
    public ResponseEntity<List<PartsStockDto>> searchStockInfo(
            @RequestParam(required = false) Long categoryId,
            @RequestParam(required = false) String name,
            @RequestParam(required = false) Integer amountMin,
            @RequestParam(required = false) Integer amountMax) {

        List<PartsStockDto> results = partsStockService.searchPartsStockInfo(categoryId, name, amountMin, amountMax);
        return ResponseEntity.ok(results);
    }
	
}
