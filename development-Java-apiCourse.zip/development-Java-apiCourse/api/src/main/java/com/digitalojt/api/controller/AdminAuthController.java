package com.digitalojt.api.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jakarta.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.digitalojt.api.dto.LoginRequestDto;
import com.digitalojt.api.form.RegisterForm;
import com.digitalojt.api.security.JwtUtil;
import com.digitalojt.api.service.AdminInfoService;

/**
 * 管理者認証APIコントローラー
 * ログイン認証とトークン発行を行う
 * 
 * /api/admin/auth/login     → JWTトークン発行
 * /api/admin/auth/register  → 管理者アカウント登録
 */

@RestController
@RequestMapping("/api/admin/auth")
public class AdminAuthController {

    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private JwtUtil jwtUtil;

    @Autowired
    private AdminInfoService adminInfoService;
    
    @GetMapping("/login")
    public String login() {
        return "redirect:/html/login/login.html";
    }

    /**
     * ログイン処理（認証成功時にJWTトークン返却）
     */
    @PostMapping("/login")
    public ResponseEntity<?> login(@Valid @RequestBody LoginRequestDto loginRequest) {
        Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(
                    loginRequest.getUsername(),
                    loginRequest.getPassword()
                )
            );
        String token = jwtUtil.generateToken(authentication);
        
        Map<String, String> response = new HashMap<>();
        response.put("token", token);
        
        return ResponseEntity.ok(response);
    }

    /**
     * 管理者アカウント登録（初期登録・開発用）
     */
    @PostMapping("/register")
    public ResponseEntity<?> register(@Valid  @RequestBody RegisterForm form, BindingResult bindingResult) {
    	
        if (bindingResult.hasErrors()) {
            // エラーメッセージをまとめて返却
            List<String> errors = bindingResult.getFieldErrors().stream()
                .map(e -> e.getField() + ": " + e.getDefaultMessage())
                .toList();
            return ResponseEntity.badRequest().body(errors);
        }

        adminInfoService.save(form);
        return ResponseEntity.ok("Admin registered successfully");
    }
}