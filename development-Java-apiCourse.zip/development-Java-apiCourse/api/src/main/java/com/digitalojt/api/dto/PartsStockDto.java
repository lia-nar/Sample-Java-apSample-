package com.digitalojt.api.dto;

import java.math.BigDecimal;

public record PartsStockDto(
	    Long id,
	    String stockCode,
	    String stockName,
	    int currentStock,
	    int safetyStock,
	    int maxStock,
	    String unit,
	    BigDecimal unitCost,
	    String shelfLocation,
	    Boolean isActive,
	    String centerName,
	    String categoryName
	) {}


