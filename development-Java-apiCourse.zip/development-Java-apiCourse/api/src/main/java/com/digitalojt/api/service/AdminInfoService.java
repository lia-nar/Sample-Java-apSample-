package com.digitalojt.api.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.digitalojt.api.entity.AdminInfo;
import com.digitalojt.api.entity.AdminInfo.Role;
import com.digitalojt.api.form.RegisterForm;
import com.digitalojt.api.repository.AdminInfoRepository;

@Service
public class AdminInfoService {

    @Autowired
    private AdminInfoRepository adminInfoRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    public void save(RegisterForm form) {
        AdminInfo admin = new AdminInfo();
        admin.setUsername(form.getUsername());
        admin.setEmail(form.getEmail());
        admin.setPasswordHash(passwordEncoder.encode(form.getPassword()));
        admin.setRole(Role.valueOf(form.getRole()));
        admin.setIsActive(Boolean.TRUE.equals(form.getIs_active()));

        adminInfoRepository.save(admin);
    }

    public AdminInfo findByUsername(String username) {
        return adminInfoRepository.findByUsername(username).orElse(null);
    }
}
