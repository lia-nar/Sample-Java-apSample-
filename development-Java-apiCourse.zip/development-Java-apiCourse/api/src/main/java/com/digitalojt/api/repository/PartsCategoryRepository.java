package com.digitalojt.api.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.digitalojt.api.entity.PartsCategory;

public interface PartsCategoryRepository extends JpaRepository<PartsCategory, Long> {
    List<PartsCategory> findAll();
}