package com.digitalojt.api.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name = "center_infos")
public class CenterInfo {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "center_code", nullable = false, length = 10, unique = true)
    private String centerCode;

    @Column(name = "center_name", nullable = false, length = 50)
    private String centerName;

    @Column(name = "is_active", nullable = false)
    private Boolean isActive;
	
}
