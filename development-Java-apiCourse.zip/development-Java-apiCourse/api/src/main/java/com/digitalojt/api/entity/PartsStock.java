package com.digitalojt.api.entity;

import java.math.BigDecimal;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name = "parts_stock")
public class PartsStock {
	
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "stock_code", nullable = false, unique = true, length = 30)
    private String stockCode;

    @Column(name = "stock_name", nullable = false, length = 200)
    private String stockName;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "category_id", nullable = false)
    private PartsCategory category;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "center_id", nullable = false)
    private CenterInfo center;

    @Column(name = "current_stock", nullable = false)
    private int currentStock;

    @Column(name = "safety_stock", nullable = false)
    private int safetyStock;

    @Column(name = "max_stock", nullable = false)
    private int maxStock;

    @Column(nullable = false, length = 10)
    private String unit;

    @Column(name = "unit_cost", nullable = false, precision = 12, scale = 2)
    private BigDecimal unitCost;

    @Column(name = "shelf_location", length = 50)
    private String shelfLocation;

    @Column(name = "is_active", nullable = false)
    private Boolean isActive;

}
