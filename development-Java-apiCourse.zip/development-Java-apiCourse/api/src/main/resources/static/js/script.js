
const DEBUG_MODE = true;

function debugLog(...args) {
    if (DEBUG_MODE) {
        console.log(...args);
    }
}

window.onload = function() {
    const token = localStorage.getItem("jwtToken");

    fetch('/api/categoryinfo/init', {
        headers: { 'Authorization': 'Bearer ' + token }
    })
    .then(response => response.json())
    .then(data => {
        debugLog('カテゴリー情報:', data);
        populateCategorySelect(data);
    })
    .catch(error => console.error('カテゴリ取得エラー:', error));

    fetch('/api/parts/category', {
        headers: { 'Authorization': 'Bearer ' + token }
    })
    .then(response => response.json())
    .then(data => {
        debugLog('名前情報:', data);
        populateNameSelect(data);
    })
    .catch(error => console.error('名前取得エラー:', error));

    fetchDataAndDisplay('/api/stockinfo/init');
};

function populateCategorySelect(categories) {
    const categorySelect = document.getElementById('categorySelect');
    categorySelect.innerHTML = '<option value="" selected>選択してください</option>';
    categories.forEach(category => {
        const option = document.createElement('option');
        option.value = category.categoryId;
        option.textContent = category.categoryName;
        categorySelect.appendChild(option);
    });
}

function populateNameSelect(names) {
    const nameSelect = document.getElementById('nameSelect');
    nameSelect.innerHTML = '<option value="" selected>選択してください</option>'; 
    names.forEach(name => {
        const option = document.createElement('option');
        option.value = name.stockCode;
        option.textContent = name.stockName;
        nameSelect.appendChild(option);
    });
}

document.getElementById('categorySelect').addEventListener('change', function() {
    const categoryId = this.value;
    if (categoryId) {
        fetch(`/api/parts/category?categoryId=${categoryId}`)
        .then(response => response.json())
        .then(data => {
            debugLog('名前情報(絞込):', data);
            populateNameSelect(data);
        })
        .catch(error => console.error('カテゴリ別名前取得エラー:', error));
    } else {
        populateNameSelect([]);
    }
});

document.getElementById('searchButton').addEventListener('click', function() {
    const categoryId = document.getElementById('categorySelect').value;
    const nameSelect = document.getElementById('nameSelect');
    const name = nameSelect.value ? nameSelect.options[nameSelect.selectedIndex].text : '';
    const amount = document.getElementById('amountSelect').value;
    const amountCondition = document.getElementById('amountConditionSelect').value;

    let url = '/api/stockinfo/search?';
    const params = [];

    if (categoryId) params.push(`categoryId=${categoryId}`);
    if (name) params.push(`name=${encodeURIComponent(name)}`);
    if (amount) {
        if (amountCondition === 'greater') {
            params.push(`amountMin=${amount}`);
        } else if (amountCondition === 'less') {
            params.push(`amountMax=${amount}`);
        }
    }

    url += params.join('&');
    fetchDataAndDisplay(url);
});

function fetchDataAndDisplay(url) {
    const displayList = document.getElementById('display-list');
    const token = localStorage.getItem("jwtToken");

    fetch(url, {
        headers: { 'Authorization': 'Bearer ' + token }
    })
    .then(response => {
        if (!response.ok) {
            return response.text().then(text => { throw new Error(text); });
        }
        return response.json();
    })
    .then(data => {
        debugLog('検索URL:', url);
        debugLog('取得データ:', data);

        displayList.innerHTML = '';
        const table = document.createElement('table');
        table.classList.add('table');
        const thead = document.createElement('thead');
        const tbody = document.createElement('tbody');

        const headerRow = document.createElement('tr');
        const headers = ['分類', '在庫名', '在庫数', 'センター', '棚番'];
        headers.forEach(headerText => {
            const th = document.createElement('th');
            th.textContent = headerText;
            headerRow.appendChild(th);
        });
        thead.appendChild(headerRow);

        data.forEach(parts => {
            const row = document.createElement('tr');
            const cells = [
                parts.categoryName || '',
                parts.stockName || parts.name || '',
                parts.currentStock || parts.amount || '',
                parts.centerName || '',
                parts.shelfLocation || parts.description || ''
            ];
            cells.forEach(cellText => {
                const td = document.createElement('td');
                td.textContent = cellText;
                row.appendChild(td);
            });
            tbody.appendChild(row);
        });

        table.appendChild(thead);
        table.appendChild(tbody);
        displayList.appendChild(table);
    })
    .catch(error => {
        console.error('データの取得中にエラーが発生しました:', error);
        displayList.innerHTML = `<span class="error-message">${error.message || 'エラーが発生しました。'}</span>`;
    });
}
